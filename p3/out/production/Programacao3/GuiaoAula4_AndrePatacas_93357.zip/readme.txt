O guiao aula 2 foi feito com recurso a polimorfismo
